import React, { useEffect, useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  UtensilsCrossed,
  Search,
  Plus,
  Edit2,
  Trash2,
  CheckCircle,
  XCircle,
  ShoppingBag,
  Mail,
  Eye,
  X,
  RefreshCw,
  Building2,
  Compass,
  Navigation,
  Upload,
  Image as ImageIcon,
  MapPin,
  ExternalLink,
  AlertTriangle,
} from 'lucide-react';
import { Restaurant, SubscriptionStatus, Order } from '../types';
import { RestaurantService } from '../services/restaurantService';
import { OrderService } from '../services/orderService';
import { StatusBadge } from '../components/common/StatusBadge';
import { ConfirmationModal } from '../components/common/ConfirmationModal';
import { EmptyState } from '../components/common/EmptyState';
import { FirebaseImage } from '../components/common/FirebaseImage';
import { uploadImageToFirebaseStorage } from '../utils/storageUtils';
import { useToast } from '../contexts/ToastContext';
import { ExportButton } from '../components/common/ExportButton';
import { exportRestaurants } from '../utils/exportUtils';
import { extractCoordinatesFromText } from '../utils/geoUtils';

export const RestaurantsPage: React.FC = () => {
  const navigate = useNavigate();
  const { success, error: toastError } = useToast();

  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [subscriptionFilter, setSubscriptionFilter] = useState<string>('all');

  // Modals state
  const [viewingRestaurant, setViewingRestaurant] = useState<Restaurant | null>(null);
  const [editingRestaurant, setEditingRestaurant] = useState<Restaurant | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [storageAuthDenied, setStorageAuthDenied] = useState(false);

  // Form states for Add / Edit
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    ownerEmail: '',
    phone: '',
    address: '',
    locationUrl: '',
    logo: '',
    rating: 5.0,
    subscriptionStatus: 'Active' as SubscriptionStatus,
    isActive: true,
  });

  const fetchRestaurants = async () => {
    setLoading(true);
    setStorageAuthDenied(false);
    try {
      const [resRestaurants, resOrders] = await Promise.all([
        RestaurantService.getAll(),
        OrderService.getAll(),
      ]);
      setRestaurants(resRestaurants.data);
      setOrders(resOrders.data);
    } catch (err) {
      console.error('Failed to load merchants or orders:', err);
      toastError('حدث خطأ أثناء تحميل بيانات التجار والطلبات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRestaurants();
  }, []);

  // Map to count total real orders in the database for each merchant
  const restaurantOrdersCount = useMemo(() => {
    const counts: Record<string, number> = {};
    orders.forEach((o) => {
      if (o.restaurantName) {
        const nameKey = o.restaurantName.trim().toLowerCase();
        counts[nameKey] = (counts[nameKey] || 0) + 1;
        counts[o.restaurantName] = (counts[o.restaurantName] || 0) + 1;
      }
      if (o.restaurantId) {
        counts[o.restaurantId] = (counts[o.restaurantId] || 0) + 1;
      }
    });
    return counts;
  }, [orders]);

  const filteredRestaurants = useMemo(() => {
    return restaurants.filter((r) => {
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        r.name.toLowerCase().includes(q) ||
        (r.category && r.category.toLowerCase().includes(q)) ||
        (r.ownerEmail && r.ownerEmail.toLowerCase().includes(q)) ||
        (r.phone && r.phone.includes(searchQuery)) ||
        (r.address && r.address.toLowerCase().includes(q)) ||
        (r.locationUrl && r.locationUrl.toLowerCase().includes(q));

      const matchesStatus =
        statusFilter === 'all'
          ? true
          : statusFilter === 'active'
          ? r.isActive
          : !r.isActive;

      const matchesSub =
        subscriptionFilter === 'all'
          ? true
          : r.subscriptionStatus === subscriptionFilter;

      return matchesSearch && matchesStatus && matchesSub;
    });
  }, [restaurants, searchQuery, statusFilter, subscriptionFilter]);

  const getMerchantLogoFallbacks = (restaurant: Restaurant): string[] => {
    const candidateIds = Array.from(
      new Set(
        [
          restaurant.id,
          restaurant.ownerUid,
          restaurant.raw?.uid,
          restaurant.raw?.userId,
          restaurant.raw?.merchantId,
          restaurant.raw?.restaurantId,
          restaurant.raw?.id,
        ].filter((v): v is string => typeof v === 'string' && v.trim().length > 0)
      )
    );

    const paths: string[] = [];
    candidateIds.forEach((mid) => {
      paths.push(`merchants/${mid}/logo/logo.jpg`);
      paths.push(`merchants/${mid}/logo/logo.png`);
      paths.push(`merchants/${mid}/logo.jpg`);
      paths.push(`merchants/${mid}/logo.png`);
      paths.push(`restaurants/${mid}/logo/logo.jpg`);
      paths.push(`restaurants/${mid}/logo/logo.png`);
      paths.push(`restaurants/${mid}/logo.jpg`);
      paths.push(`restaurants/${mid}/logo.png`);
      paths.push(`merchants/${mid}/logo`);
      paths.push(`restaurants/${mid}/logo`);
      paths.push(`merchants/${mid}`);
      paths.push(`restaurants/${mid}`);
      paths.push(`logos/${mid}`);
      paths.push(`users/${mid}`);
    });
    return paths;
  };

  const handleLogoFileChange = async (e: React.ChangeEvent<HTMLInputElement>, merchantId?: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLogo(true);
    try {
      const folderId = merchantId || `merchant_${Date.now()}`;
      const ext = file.name.split('.').pop() || 'png';
      const storagePath = `merchants/${folderId}/logo/logo_${Date.now()}.${ext}`;
      const downloadUrl = await uploadImageToFirebaseStorage(file, storagePath);
      setFormData((prev) => ({ ...prev, logo: downloadUrl }));
      success('تم رفع صورة اللوجو للتاجر بنجاح');
    } catch (err) {
      toastError('فشل رفع صورة اللوجو');
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleToggleStatus = async (restaurant: Restaurant) => {
    try {
      const newStatus = await RestaurantService.toggleActive(restaurant.id, restaurant.isActive);
      setRestaurants((prev) =>
        prev.map((r) => (r.id === restaurant.id ? { ...r, isActive: newStatus } : r))
      );
      success(newStatus ? `تم تفعيل التاجر "${restaurant.name}"` : `تم إيقاف التاجر "${restaurant.name}"`);
    } catch (err) {
      toastError('فشل تغيير حالة التاجر');
    }
  };

  const handleOpenEdit = (restaurant: Restaurant) => {
    setEditingRestaurant(restaurant);
    setFormData({
      name: restaurant.name,
      category: restaurant.category || '',
      ownerEmail: restaurant.ownerEmail && restaurant.ownerEmail !== '—' ? restaurant.ownerEmail : '',
      phone: restaurant.phone && restaurant.phone !== '—' ? restaurant.phone : '',
      address: restaurant.address && restaurant.address !== '—' ? restaurant.address : '',
      locationUrl: restaurant.locationUrl || '',
      logo: restaurant.logo || restaurant.image || '',
      rating: restaurant.rating || 5.0,
      subscriptionStatus: restaurant.subscriptionStatus || 'Active',
      isActive: restaurant.isActive,
    });
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRestaurant) return;

    setActionLoading(true);
    try {
      const trimmedLocationUrl = formData.locationUrl.trim();
      const parsedCoords = trimmedLocationUrl ? extractCoordinatesFromText(trimmedLocationUrl) : null;

      await RestaurantService.update(editingRestaurant.id, {
        name: formData.name,
        category: formData.category,
        ownerEmail: formData.ownerEmail || '—',
        phone: formData.phone,
        address: formData.address,
        locationUrl: trimmedLocationUrl,
        logo: formData.logo,
        subscriptionStatus: formData.subscriptionStatus,
      });

      setRestaurants((prev) =>
        prev.map((r) =>
          r.id === editingRestaurant.id
            ? {
                ...r,
                ...formData,
                locationUrl: trimmedLocationUrl || undefined,
                coords: parsedCoords || r.coords || null,
                ownerEmail: formData.ownerEmail || '—',
              }
            : r
        )
      );

      success('تم تحديث بيانات التاجر بنجاح');
      setEditingRestaurant(null);
    } catch (err) {
      toastError('فشل حفظ تعديلات التاجر');
    } finally {
      setActionLoading(false);
    }
  };

  const handleAddRestaurant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toastError('يرجى إدخال اسم التاجر');
      return;
    }

    setActionLoading(true);
    try {
      const trimmedLocationUrl = formData.locationUrl.trim();
      const newRest = await RestaurantService.create({
        name: formData.name,
        category: formData.category || 'عام',
        ownerEmail: formData.ownerEmail || '—',
        phone: formData.phone || '',
        address: formData.address || '',
        locationUrl: trimmedLocationUrl || undefined,
        logo: formData.logo || '',
        rating: 5.0,
        subscriptionStatus: formData.subscriptionStatus,
        isActive: formData.isActive,
      });

      setRestaurants((prev) => [newRest, ...prev]);
      success('تم تسجيل التاجر الجديد بنجاح');
      setIsAddModalOpen(false);
      setFormData({
        name: '',
        category: '',
        ownerEmail: '',
        phone: '',
        address: '',
        locationUrl: '',
        logo: '',
        rating: 5.0,
        subscriptionStatus: 'Active',
        isActive: true,
      });
    } catch (err) {
      toastError('فشل إضافة التاجر');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteConfirm = async () => {
    if (!deletingId) return;
    setActionLoading(true);
    try {
      await RestaurantService.delete(deletingId);
      setRestaurants((prev) => prev.filter((r) => r.id !== deletingId));
      success('تم حذف التاجر بنجاح');
      setDeletingId(null);
    } catch (err) {
      toastError('فشل حذف التاجر');
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white">إدارة التجار</h2>
          <p className="text-xs sm:text-sm text-zinc-400 mt-0.5">
            متابعة التجار وشركاء El Batal Express وتعديل بياناتهم وتفعيل الخدمات
          </p>
        </div>

        <div className="flex items-center gap-3">
          <ExportButton
            onExportExcel={() => exportRestaurants(filteredRestaurants, 'xlsx')}
            onExportCsv={() => exportRestaurants(filteredRestaurants, 'csv')}
            label="تصدير التجار"
            count={filteredRestaurants.length}
          />

          <button
            onClick={fetchRestaurants}
            className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
            title="تحديث القائمة"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setFormData({
                name: '',
                category: '',
                ownerEmail: '',
                phone: '',
                address: '',
                locationUrl: '',
                logo: '',
                rating: 5.0,
                subscriptionStatus: 'Active',
                isActive: true,
              });
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-black text-xs sm:text-sm shadow-md shadow-amber-500/10 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة تاجر جديد</span>
          </button>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-[#11141c] border border-zinc-800/90 rounded-2xl p-4 flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-zinc-400 absolute right-3.5 top-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="البحث باسم التاجر أو التصنيف أو البريد الإلكتروني أو الهاتف..."
            className="w-full bg-[#0a0c12] border border-zinc-800 text-zinc-100 placeholder-zinc-500 rounded-xl py-2.5 pr-10 pl-4 text-xs sm:text-sm focus:outline-none focus:border-amber-500 transition-colors"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status filter */}
          <div className="flex items-center rounded-xl bg-[#0a0c12] border border-zinc-800 p-1 text-xs">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                statusFilter === 'all' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              الكل ({restaurants.length})
            </button>
            <button
              onClick={() => setStatusFilter('active')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                statusFilter === 'active' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              نشط ({restaurants.filter((r) => r.isActive).length})
            </button>
            <button
              onClick={() => setStatusFilter('inactive')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
                statusFilter === 'inactive' ? 'bg-amber-500 text-zinc-950' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              موقوف ({restaurants.filter((r) => !r.isActive).length})
            </button>
          </div>

          {/* Subscription filter */}
          <select
            value={subscriptionFilter}
            onChange={(e) => setSubscriptionFilter(e.target.value)}
            className="bg-[#0a0c12] border border-zinc-800 text-zinc-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
          >
            <option value="all">كل الاشتراكات</option>
            <option value="Active">ساري (Active)</option>
            <option value="Pending">معلق (Pending)</option>
            <option value="Expired">منتهي (Expired)</option>
            <option value="Suspended">موقوف (Suspended)</option>
          </select>
        </div>
      </div>

      {/* Firebase Storage Rules Notice when unauthorized */}
      {storageAuthDenied && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 flex items-start gap-3 text-xs text-amber-200">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-extrabold text-amber-300 mb-1">
              قواعد Firebase Storage تمنع قراءة بعض شعارات التجار (storage/unauthorized)
            </p>
            <p className="text-amber-200/80 leading-relaxed">
              تأكد من نشر ملف <span className="font-mono text-white">storage.rules</span> المحدث في مشروع Firebase لتفعيل قراءة شعارات التجار من المسارات{' '}
              <span className="font-mono text-white" dir="ltr">
                merchants/&#123;merchantId&#125;/...
              </span>{' '}
              و{' '}
              <span className="font-mono text-white" dir="ltr">
                restaurants/&#123;merchantId&#125;/...
              </span>
              .
            </p>
          </div>
        </div>
      )}

      {/* Merchants Table */}
      <div className="bg-[#11141c] border border-zinc-800/90 rounded-3xl shadow-xl overflow-hidden">
        {loading ? (
          <div className="p-12 text-center">
            <div className="w-8 h-8 border-3 border-amber-500/20 border-t-amber-500 rounded-full animate-spin mx-auto mb-3" />
            <p className="text-zinc-400 text-xs font-semibold">جاري جلب بيانات التجار من Firestore...</p>
          </div>
        ) : filteredRestaurants.length === 0 ? (
          <div className="p-8">
            <EmptyState
              title="لم يتم العثور على تجار"
              description="لا توجد نتائج تطابق معايير البحث أو التصفية الحالية."
              icon={UtensilsCrossed}
              actionText="إعادة ضبط البحث"
              onAction={() => {
                setSearchQuery('');
                setStatusFilter('all');
                setSubscriptionFilter('all');
              }}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-xs font-bold text-zinc-400 bg-zinc-950/40">
                  <th className="py-4 px-4">اسم التجار</th>
                  <th className="py-4 px-4">صورة اللوجو للتاجر</th>
                  <th className="py-4 px-4">التصنيف</th>
                  <th className="py-4 px-4">البريد الإلكتروني</th>
                  <th className="py-4 px-4">رقم الهاتف</th>
                  <th className="py-4 px-4">رابط الموقع / الخريطة</th>
                  <th className="py-4 px-4">الطلبات</th>
                  <th className="py-4 px-4">حالة الاشتراك</th>
                  <th className="py-4 px-4">الحالة</th>
                  <th className="py-4 px-4">تاريخ التسجيل</th>
                  <th className="py-4 px-4 text-left">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {filteredRestaurants.map((restaurant) => {
                  const ordersCount =
                    restaurantOrdersCount[restaurant.name] ??
                    restaurantOrdersCount[restaurant.name.trim().toLowerCase()] ??
                    restaurantOrdersCount[restaurant.id] ??
                    0;

                  const storageFallbacks = getMerchantLogoFallbacks(restaurant);

                  return (
                    <tr key={restaurant.id} className="hover:bg-zinc-900/40 transition-colors">
                      {/* اسم التجار */}
                      <td className="py-4 px-4">
                        <div className="flex flex-col gap-1">
                          <p className="font-extrabold text-zinc-100 text-sm">{restaurant.name}</p>
                          {restaurant.address && restaurant.address !== '—' && (
                            <p className="text-xs text-zinc-500 truncate max-w-xs">{restaurant.address}</p>
                          )}
                        </div>
                      </td>

                      {/* صورة اللوجو للتاجر */}
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-2">
                          <FirebaseImage
                            src={restaurant.logoPath || restaurant.logo || restaurant.image}
                            fallbackStoragePaths={storageFallbacks}
                            alt={`لوجو ${restaurant.name}`}
                            className="w-11 h-11 rounded-2xl border border-amber-500/30 shadow-xs"
                            onClick={() => setViewingRestaurant(restaurant)}
                            onErrorCode={(code) => {
                              if (code === 'storage/unauthorized') {
                                setStorageAuthDenied(true);
                              }
                            }}
                            fallbackContent={
                              <div className="w-full h-full bg-amber-500/10 text-amber-400 flex items-center justify-center font-black text-sm">
                                {restaurant.name.charAt(0)}
                              </div>
                            }
                          />
                        </div>
                      </td>

                      {/* التصنيف */}
                      <td className="py-4 px-4 text-xs font-semibold text-zinc-300">
                        <span className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800">
                          {restaurant.category || 'عام'}
                        </span>
                      </td>

                      {/* البريد الإلكتروني */}
                      <td className="py-4 px-4 text-xs font-mono text-zinc-300" dir="ltr">
                        {restaurant.ownerEmail && restaurant.ownerEmail !== '—' ? (
                          <div className="inline-flex items-center gap-1.5 text-zinc-200">
                            <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span className="truncate max-w-[180px]">{restaurant.ownerEmail}</span>
                          </div>
                        ) : (
                          <span className="text-zinc-500">—</span>
                        )}
                      </td>

                      {/* رقم الهاتف */}
                      <td className="py-4 px-4 text-xs font-mono text-zinc-300" dir="ltr">
                        {restaurant.phone || '—'}
                      </td>

                      {/* رابط الموقع / الخريطة */}
                      <td className="py-4 px-4">
                        <div className="flex flex-col items-start gap-1.5 min-w-[155px]">
                          {restaurant.locationUrl ? (
                            <a
                              href={restaurant.locationUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-sky-400 hover:text-sky-300 underline decoration-sky-500/40 underline-offset-2 max-w-[190px]"
                              title={restaurant.locationUrl}
                            >
                              <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate" dir="ltr">
                                {restaurant.locationUrl}
                              </span>
                            </a>
                          ) : (
                            <span className="text-[11px] text-zinc-500">لا يوجد رابط موقع</span>
                          )}

                          {(restaurant.coords || restaurant.locationUrl) && (
                            <button
                              type="button"
                              onClick={() =>
                                navigate(`/live-map?restaurantId=${encodeURIComponent(restaurant.id)}`)
                              }
                              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-colors cursor-pointer ${
                                restaurant.coords
                                  ? 'bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400'
                                  : 'bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300'
                              }`}
                              title="تحديد موقع التاجر على الخرائط المباشرة"
                            >
                              <MapPin className="w-3.5 h-3.5 shrink-0" />
                              <span>{restaurant.coords ? 'تحديد على الخريطة' : 'تثبيت على الخريطة'}</span>
                            </button>
                          )}
                        </div>
                      </td>

                      {/* الطلبات */}
                      <td className="py-4 px-4">
                        <button
                          onClick={() => navigate(`/orders?restaurant=${encodeURIComponent(restaurant.name)}`)}
                          className="group inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 hover:border-amber-500/60 text-amber-400 text-xs font-bold transition-all hover:scale-105 cursor-pointer shadow-xs"
                          title={`عرض جميع طلبات التاجر ${restaurant.name}`}
                        >
                          <ShoppingBag className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
                          <span>{ordersCount} طلب</span>
                        </button>
                      </td>

                      {/* حالة الاشتراك */}
                      <td className="py-4 px-4">
                        <StatusBadge status={restaurant.subscriptionStatus || 'Active'} type="subscription" />
                      </td>

                      {/* الحالة */}
                      <td className="py-4 px-4">
                        <StatusBadge status={restaurant.isActive} type="restaurant" />
                      </td>

                      {/* تاريخ التسجيل */}
                      <td className="py-4 px-4 text-xs text-zinc-400">
                        {restaurant.createdAt
                          ? new Date(restaurant.createdAt).toLocaleDateString('ar-EG', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })
                          : '—'}
                      </td>

                      {/* الإجراءات */}
                      <td className="py-4 px-4 text-left">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setViewingRestaurant(restaurant)}
                            className="p-1.5 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/80 rounded-lg transition-colors"
                            title="عرض التفاصيل"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => handleToggleStatus(restaurant)}
                            className={`p-1.5 rounded-lg transition-colors ${
                              restaurant.isActive
                                ? 'text-rose-400 hover:bg-rose-500/10'
                                : 'text-emerald-400 hover:bg-emerald-500/10'
                            }`}
                            title={restaurant.isActive ? 'إيقاف التاجر' : 'تفعيل التاجر'}
                          >
                            {restaurant.isActive ? (
                              <XCircle className="w-4 h-4" />
                            ) : (
                              <CheckCircle className="w-4 h-4" />
                            )}
                          </button>

                          <button
                            onClick={() => handleOpenEdit(restaurant)}
                            className="p-1.5 text-zinc-400 hover:text-amber-400 hover:bg-zinc-800/80 rounded-lg transition-colors"
                            title="تعديل بيانات التاجر"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => setDeletingId(restaurant.id)}
                            className="p-1.5 text-zinc-400 hover:text-rose-400 hover:bg-zinc-800/80 rounded-lg transition-colors"
                            title="حذف التاجر"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* View Details Modal */}
      {viewingRestaurant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#11141c] border border-zinc-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setViewingRestaurant(null)}
              className="absolute top-5 left-5 text-zinc-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-4 mb-6">
              <FirebaseImage
                src={viewingRestaurant.logoPath || viewingRestaurant.logo || viewingRestaurant.image}
                fallbackStoragePaths={getMerchantLogoFallbacks(viewingRestaurant)}
                alt={viewingRestaurant.name}
                className="w-16 h-16 rounded-2xl border border-amber-500/30"
                onErrorCode={(code) => {
                  if (code === 'storage/unauthorized') {
                    setStorageAuthDenied(true);
                  }
                }}
                fallbackContent={
                  <div className="w-full h-full bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold text-lg">
                    <Building2 className="w-7 h-7" />
                  </div>
                }
              />
              <div>
                <h3 className="text-lg font-black text-white">{viewingRestaurant.name}</h3>
                <p className="text-xs text-zinc-400">
                  معرف التاجر: <span className="font-mono">{viewingRestaurant.id}</span>
                  {viewingRestaurant.sourceCollection && (
                    <span className="mr-2 px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-mono text-[10px]">
                      {viewingRestaurant.sourceCollection}
                    </span>
                  )}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs mb-6">
              <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1">التصنيف</span>
                <span className="font-bold text-zinc-200">{viewingRestaurant.category || 'عام'}</span>
              </div>
              <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1">رقم الهاتف</span>
                <span className="font-bold text-zinc-200 font-mono" dir="ltr">
                  {viewingRestaurant.phone || '—'}
                </span>
              </div>
              <div className="col-span-2 p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1">البريد الإلكتروني للتاجر</span>
                <span className="font-bold text-zinc-200 font-mono" dir="ltr">
                  {viewingRestaurant.ownerEmail || '—'}
                </span>
              </div>
              <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1">الحالة</span>
                <StatusBadge status={viewingRestaurant.isActive} type="restaurant" />
              </div>
              <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1">حالة الاشتراك</span>
                <StatusBadge status={viewingRestaurant.subscriptionStatus || 'Active'} type="subscription" />
              </div>
              {(viewingRestaurant.subscriptionPlan || viewingRestaurant.subscriptionEndDate) && (
                <div className="col-span-2 p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-zinc-500 block mb-0.5">باقة الاشتراك</span>
                    <span className="font-bold text-amber-400">
                      {viewingRestaurant.subscriptionPlan ||
                        (viewingRestaurant.captainsCount
                          ? `${viewingRestaurant.captainsCount} كابتن`
                          : 'الباقة القياسية')}
                    </span>
                  </div>
                  {viewingRestaurant.subscriptionEndDate && (
                    <div className="text-left">
                      <span className="text-zinc-500 block mb-0.5">تاريخ الانتهاء</span>
                      <span className="font-mono font-bold text-zinc-200">
                        {new Date(viewingRestaurant.subscriptionEndDate).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                  )}
                </div>
              )}
              <div className="col-span-2 p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1">العنوان والموقع</span>
                <span className="font-bold text-zinc-200">{viewingRestaurant.address || 'غير محدد'}</span>
              </div>
              <div className="col-span-2 p-3.5 rounded-xl bg-zinc-900/80 border border-zinc-800">
                <span className="text-zinc-500 block mb-1.5">رابط الموقع الذي أضافه التاجر</span>
                {viewingRestaurant.locationUrl ? (
                  <div className="flex flex-col gap-1.5">
                    <a
                      href={viewingRestaurant.locationUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sky-400 hover:text-sky-300 font-semibold break-all underline decoration-sky-500/40"
                      dir="ltr"
                    >
                      <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                      <span>{viewingRestaurant.locationUrl}</span>
                    </a>
                    {viewingRestaurant.coords && (
                      <span className="text-[11px] text-emerald-400 font-mono" dir="ltr">
                        GPS (محدد تلقائياً على الخريطة): {viewingRestaurant.coords.lat.toFixed(6)},{' '}
                        {viewingRestaurant.coords.lng.toFixed(6)}
                      </span>
                    )}
                  </div>
                ) : (
                  <span className="text-zinc-500">لم يضف التاجر رابط موقع بعد</span>
                )}
              </div>
            </div>

            {/* Orders Section in Modal */}
            <div className="mb-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center font-bold">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-zinc-400 block">إجمالي طلبات التاجر</span>
                  <span className="text-sm font-black text-amber-400 font-['Outfit',sans-serif]">
                    {(restaurantOrdersCount[viewingRestaurant.name] ??
                      restaurantOrdersCount[viewingRestaurant.name.trim().toLowerCase()] ??
                      restaurantOrdersCount[viewingRestaurant.id] ??
                      0)}{' '}
                    طلب مسجل في قاعدة البيانات
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  navigate(`/orders?restaurant=${encodeURIComponent(viewingRestaurant.name)}`);
                  setViewingRestaurant(null);
                }}
                className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <span>عرض كافة الطلبات</span>
              </button>
            </div>

            {/* Live Map navigation */}
            <div className="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-bold">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-xs text-zinc-400 block">الخريطة المباشرة وتحديد الكباتن</span>
                  <span className="text-xs font-bold text-emerald-300">
                    تتبع موقع التاجر والبحث عن أقرب كابتن متاح
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  navigate(`/live-map?restaurantId=${encodeURIComponent(viewingRestaurant.id)}`);
                  setViewingRestaurant(null);
                }}
                className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
              >
                <Navigation className="w-4 h-4" />
                <span>تحديد على الخريطة</span>
              </button>
            </div>

            {viewingRestaurant.raw && Object.keys(viewingRestaurant.raw).length > 0 && (
              <div className="mt-4 pt-4 border-t border-zinc-800/80">
                <details className="text-[11px] text-zinc-400">
                  <summary className="cursor-pointer font-bold text-amber-400 hover:underline">
                    عرض الحقول الكاملة المخزنة في Firestore (Schema Inspector)
                  </summary>
                  <pre className="mt-2 p-3 rounded-xl bg-[#090b10] border border-zinc-800 text-[10px] text-zinc-300 overflow-x-auto font-mono">
                    {JSON.stringify(viewingRestaurant.raw, null, 2)}
                  </pre>
                </details>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Merchant Modal */}
      {editingRestaurant && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#11141c] border border-zinc-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setEditingRestaurant(null)}
              className="absolute top-5 left-5 text-zinc-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black text-white mb-4">تعديل بيانات التاجر</h3>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">اسم التاجر *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              {/* Merchant Logo Upload / URL */}
              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">صورة اللوجو للتاجر</label>
                <div className="flex items-center gap-3 mb-2">
                  <FirebaseImage
                    src={formData.logo}
                    alt="لوجو التاجر"
                    className="w-12 h-12 rounded-2xl border border-zinc-700"
                    fallbackContent={
                      <div className="w-full h-full bg-zinc-900 text-zinc-500 flex items-center justify-center">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                    }
                  />
                  <label className="flex-1 cursor-pointer flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 font-bold transition-colors">
                    <Upload className="w-4 h-4 text-amber-400" />
                    <span>{uploadingLogo ? 'جاري رفع اللوجو...' : 'رفع لوجو من الجهاز (Storage)'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleLogoFileChange(e, editingRestaurant.id)}
                      className="hidden"
                      disabled={uploadingLogo}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={formData.logo}
                  onChange={(e) => setFormData({ ...formData, logo: e.target.value })}
                  dir="ltr"
                  placeholder="أو ضع رابط مباشر للصورة أو مسار Firebase Storage..."
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">التصنيف</label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="مثال: مأكولات شرقية، برجر، بيتزا، سوبر ماركت"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={formData.ownerEmail}
                  onChange={(e) => setFormData({ ...formData, ownerEmail: e.target.value })}
                  dir="ltr"
                  placeholder="merchant@example.com"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">رقم الهاتف</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  dir="ltr"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">العنوان</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">رابط الموقع (Google Maps)</label>
                <input
                  type="text"
                  value={formData.locationUrl}
                  onChange={(e) => setFormData({ ...formData, locationUrl: e.target.value })}
                  dir="ltr"
                  placeholder="https://maps.google.com/?q=30.0444,31.2357"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
                {formData.locationUrl.trim() && (
                  <p className="mt-1 text-[11px]">
                    {extractCoordinatesFromText(formData.locationUrl) ? (
                      <span className="text-emerald-400">
                        ✓ تم استخراج الإحداثيات بنجاح للعرض على الخرائط المباشرة
                      </span>
                    ) : (
                      <span className="text-zinc-400">
                        سيتم حفظ الرابط كما هو (يفضل رابط يحتوي على الإحداثيات مثل @lat,lng للظهور على الخريطة)
                      </span>
                    )}
                  </p>
                )}
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">حالة الاشتراك</label>
                <select
                  value={formData.subscriptionStatus}
                  onChange={(e) =>
                    setFormData({ ...formData, subscriptionStatus: e.target.value as SubscriptionStatus })
                  }
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                >
                  <option value="Active">ساري (Active)</option>
                  <option value="Pending">معلق (Pending)</option>
                  <option value="Expired">منتهي (Expired)</option>
                  <option value="Suspended">موقوف (Suspended)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-800/80">
                <button
                  type="button"
                  onClick={() => setEditingRestaurant(null)}
                  className="px-4 py-2 text-zinc-400 hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={actionLoading || uploadingLogo}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold transition-colors disabled:opacity-50"
                >
                  {actionLoading ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Merchant Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#11141c] border border-zinc-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-5 left-5 text-zinc-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-black text-white mb-4">تسجيل تاجر جديد في المنظومة</h3>

            <form onSubmit={handleAddRestaurant} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">اسم التاجر *</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="مثال: النجم الذهبي"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">صورة اللوجو للتاجر</label>
                <div className="flex items-center gap-3 mb-2">
                  <FirebaseImage
                    src={formData.logo}
                    alt="لوجو التاجر"
                    className="w-12 h-12 rounded-2xl border border-zinc-700"
                    fallbackContent={
                      <div className="w-full h-full bg-zinc-900 text-zinc-500 flex items-center justify-center">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                    }
                  />
                  <label className="flex-1 cursor-pointer flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 font-bold transition-colors">
                    <Upload className="w-4 h-4 text-amber-400" />
                    <span>{uploadingLogo ? 'جاري الرفع...' : 'رفع صورة اللوجو'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleLogoFileChange(e)}
                      className="hidden"
                      disabled={uploadingLogo}
                    />
                  </label>
                </div>
                <input
                  type="text"
                  value={formData.logo}
                  onChange={(e) => setFormData({ ...formData, logo: e.target.value })}
                  dir="ltr"
                  placeholder="أو رابط اللوجو المباشر..."
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">التصنيف</label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="وجبات سريعة، مشويات، سوبر ماركت..."
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">البريد الإلكتروني</label>
                <input
                  type="email"
                  value={formData.ownerEmail}
                  onChange={(e) => setFormData({ ...formData, ownerEmail: e.target.value })}
                  dir="ltr"
                  placeholder="merchant@example.com"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">رقم الهاتف</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  dir="ltr"
                  placeholder="010XXXXXXXX"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">العنوان</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="المدينة، الشارع، علامة مميزة"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-zinc-300 mb-1.5">رابط الموقع (Google Maps)</label>
                <input
                  type="text"
                  value={formData.locationUrl}
                  onChange={(e) => setFormData({ ...formData, locationUrl: e.target.value })}
                  dir="ltr"
                  placeholder="https://maps.google.com/?q=30.0444,31.2357"
                  className="w-full bg-[#0a0c12] border border-zinc-800 rounded-xl px-3.5 py-2.5 text-zinc-100 focus:outline-none focus:border-amber-500"
                />
                {formData.locationUrl.trim() && (
                  <p className="mt-1 text-[11px]">
                    {extractCoordinatesFromText(formData.locationUrl) ? (
                      <span className="text-emerald-400">
                        ✓ تم استخراج الإحداثيات بنجاح للعرض على الخرائط المباشرة
                      </span>
                    ) : (
                      <span className="text-zinc-400">
                        سيتم حفظ الرابط كما هو (يفضل رابط يحتوي على الإحداثيات مثل @lat,lng للظهور على الخريطة)
                      </span>
                    )}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-zinc-800/80">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-zinc-400 hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={actionLoading || uploadingLogo}
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold transition-colors disabled:opacity-50"
                >
                  {actionLoading ? 'جاري الإضافة...' : 'تسجيل التاجر'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={Boolean(deletingId)}
        title="تأكيد حذف التاجر"
        message="هل أنت متأكد من رغبتك في حذف هذا التاجر من النظام؟ لا يمكن التراجع عن هذه الخطوة."
        confirmText="حذف نهائي"
        cancelText="تراجع"
        isDanger={true}
        isLoading={actionLoading}
        onConfirm={handleDeleteConfirm}
        onClose={() => setDeletingId(null)}
      />
    </div>
  );
};
